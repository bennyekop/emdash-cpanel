declare module 'astro:assets' {
	/** @internal */
	export type CssVariable = (["--font-sans","--font-mono"])[number];
}
